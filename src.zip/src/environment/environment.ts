//you should replace this values with yours

export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyCHjrxeH8VUADKLhR5Csa54cqPRMDr4Pw8",
    authDomain: "rosy-dynamics-171007.firebaseapp.com",
    databaseURL: "https://rosy-dynamics-171007.firebaseio.com",
    projectId: "rosy-dynamics-171007",
    storageBucket: "rosy-dynamics-171007.appspot.com",
    messagingSenderId: "303898922125"
  },
  google_web_client_id: "1092390853283-i98feg7fb1dlsm92kkcbim62855pepi8.apps.googleusercontent.com",
  facebook_app_id: 1429694130495692,
  wordpress_url: 'https://www.hyroglf.net',
  wordpress_rest_api_url: 'https://www.hyroglf.net/wp-json/wp/v2/',
  wordpress_admin_url: 'https://hyroglf.net/wp-admin/admin-ajax.php',
  jwt_url: "https://hyroglf.net/wp-json/jwt-auth/v1/token",
  registration_url: "https://www.hyroglf.net/wp-json/wp/v2/users",
  current_user_url : "https://hyroglf.net/wp-json/wp/v2/users/me"
};
