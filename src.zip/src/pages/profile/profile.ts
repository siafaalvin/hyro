import { Component } from '@angular/core';
import { MenuController, SegmentButton, App, NavParams } from 'ionic-angular';
import { FollowersPage } from '../followers/followers';
import { SettingsPage } from '../settings/settings';
import { ProfileModel } from './profile.model';
import { ProfileService } from './profile.service';
import { SocialSharing } from '@ionic-native/social-sharing';
import { WordpressService } from '../wordpress-integration/wordpress-integration.service';
import { NavController } from 'ionic-angular';
import { BlogPostPage } from '../wordpress-integration/blog-post/blog-post';
import 'rxjs/Rx';

@Component({
  selector: 'profile-page',
  templateUrl: 'profile.html'
})
export class ProfilePage {
  display: string;
  profile: ProfileModel = new ProfileModel();
  user: any;
  userExtended: any;
  ready: boolean;
  page: number;
  posts: any[];
  likes: any[];

  constructor(
    public navCtrl: NavController, 
    public menu: MenuController,
    public app: App,
    public navParams: NavParams,
    public profileService: ProfileService,
    public socialSharing: SocialSharing,
    public wordpressService: WordpressService,
  ) {
    this.display = "list";
    this.ready = false;
    this.posts = [];
  }

  ionViewDidLoad() {
    let token = localStorage.getItem('_token');
    if (!token || token.length < 1) {
      return null;
    } else {
      this.wordpressService.getProfile().subscribe((data : any) => {
        this.user = JSON.parse(data._body);
        this.user.first_name = (this.user.first_name) ? this.user.first_name : 'N\A';
        this.user.second_name = (this.user.second_name) ? this.user.second_name : 'N\A';
        this.user.description = (this.user.description) ? this.user.description : '';
        this.user.image = (this.user.avatar_urls[96]) ? this.user.avatar_urls[96] : './assets/images/no profile.png';
        this.wordpressService.getProfileExtended().subscribe((extendData: any) => {
          this.userExtended = JSON.parse(extendData._body);
          this.userExtended.fb_link = (this.userExtended.fb_link) ? this.userExtended.fb_link : 'N\A';
          this.userExtended.google_link = (this.userExtended.google_link) ? this.userExtended.google_link : 'N\A';
          this.userExtended.twitter_link = (this.userExtended.twitter_link) ? this.userExtended.twitter_link : 'N\A';
        });
        this.loadMorePosts(1);
        this.loadLikes();
        this.ready = true;
      }, (error:any) => {
        console.log(error);
      });
    }
    this.profileService.getData()
      .then(data => {
        this.profile.user = data.user;
        this.profile.following = data.following;
        this.profile.followers = data.followers;
        this.profile.posts = data.posts;
      });
  }

  loadMorePosts (page: any) {
    this.wordpressService.getPostByAuthor(page).subscribe((data: any) => {
      let rawData = JSON.parse(data._body);
      this.posts = this.posts.concat(rawData);
      this.posts = this.posts.map((row) => {
        if (row.featured_media) {
          row.image = row['_embedded']['wp:featuredmedia'][0]['source_url'];
        } else {
          row.image = '';
        }
        return row;
      });
    });
  }

  loadLikes () {
    this.wordpressService.likes().subscribe((data: any) => {
      let rawData = JSON.parse(data._body);
      this.likes = rawData.list;
      console.log(this.likes);
    });
  }

  goToFollowersList() {
    // close the menu when clicking a link from the menu
    this.menu.close();
    this.app.getRootNav().push(FollowersPage, {
      list: this.profile.followers
    });
  }

  goToFollowingList() {
    // close the menu when clicking a link from the menu
    this.menu.close();
    this.app.getRootNav().push(FollowersPage, {
      list: this.profile.following
    });
  }

  goToSettings() {
    // close the menu when clicking a link from the menu
    this.menu.close();
    this.app.getRootNav().push(SettingsPage);
  }

  onSegmentChanged(segmentButton: SegmentButton) {
    // console.log('Segment changed to', segmentButton.value);
  }

  onSegmentSelected(segmentButton: SegmentButton) {
    // console.log('Segment selected', segmentButton.value);
  }

  sharePost(post) {
   //this code is to use the social sharing plugin
   // message, subject, file, url
   this.socialSharing.share(post.description, post.title, post.image)
   .then(() => {
     console.log('Success!');
   })
   .catch(() => {
      console.log('Error');
   });
  }

  readMore(post) {
		this.navCtrl.push(BlogPostPage, {
		  post: post
		});
  }
}
