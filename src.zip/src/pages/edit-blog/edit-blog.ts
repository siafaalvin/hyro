import { Component } from '@angular/core';
import { NavController, NavParams, LoadingController } from 'ionic-angular';
import { BlogPostModel } from '../wordpress-integration/blog-post.model';
import { WordpressService } from '../wordpress-integration/wordpress-integration.service';
import { SelectSearchableComponent } from 'ionic-select-searchable';
import { CameraOptions, Camera } from '@ionic-native/camera';
import { FileTransfer } from '@ionic-native/file-transfer';
import { environment } from '../../environment/environment';
import { BlogPostPage } from '../wordpress-integration/blog-post/blog-post';
import { WordpressLoginPage } from '../wordpress-integration/wordpress-login/wordpress-login';
import { Events } from 'ionic-angular/';
/**
 * Generated class for the EditBlogPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-edit-blog',
  templateUrl: 'edit-blog.html',
})
export class EditBlogPage {

  post: BlogPostModel = new BlogPostModel();
  category: any;
  categories: any;
  myphoto: string;
  old_summary: string;
  word_count: number;

  constructor(public navCtrl: NavController, public navParams: NavParams, 
    private camera: Camera,
    private transfer: FileTransfer,
    public loadingCtrl: LoadingController,
    public wordpressService: WordpressService,
    public events: Events) {
      this.post = this.navParams.get('post');
      this.word_count = 0;
      console.log(this.post);
      this.category = this.post.categories_list;
      this.post.content.rendered = this.post.content.rendered.replace(/<[^>]*>/g, '').trim();
      this.updatelength({});
      this.wordpressService.getCategories().subscribe(data => {
        this.categories = data;
      });
          
  }

  updatelength (searchValue) {
    let length = 0;
    if (searchValue.length > 0){
      length = 1;
      let raw_count = searchValue.split(/[\s\n]+/).length;
      
      if (raw_count > length) {
        length = raw_count - 1;
      }

      if (raw_count < 80) {
        this.post.content.rendered = searchValue;
        this.old_summary = searchValue;
      } else {
        this.post.content.rendered = this.old_summary;
        searchValue = this.old_summary;
      }
    }
    this.word_count = length;
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad EditBlogPage');
  }

  selectImage(){
    const options: CameraOptions = {
      quality: 70,
      destinationType: this.camera.DestinationType.DATA_URL,
      sourceType: this.camera.PictureSourceType.PHOTOLIBRARY,
      saveToPhotoAlbum:false
    }

    this.camera.getPicture(options).then(imageData => {
      this.myphoto = 'data:image/jpeg;base64,' + imageData;
    }, error => {
      console.log(error);
    })
  }

  processContent (text) {
    let raw = text.split(/[\;\.]+/);
    let html = '<ul>';
    for (let i = 0; i < raw.length; i++) {
      const element = raw[i];
      html = html + '<li>' + element + '.</li>';
    }
    html = html + '</ul>';
    return html;
  }

  updatePost(post:any, categories:any){
    post.categories = [];
    post.title = post.title.rendered;
    post.content = this.processContent(post.content.rendered);
    let self = this;
    categories.forEach(function(category:any){
      post.categories.push(category.id);
    });

    post.date = new Date(post.date);
    // console.log(post, "before");

    if(this.myphoto){
      var trnsf = this.transfer.create();
      trnsf.upload(this.myphoto, environment.wordpress_rest_api_url + 'media', {
        headers: {
          'Authorization' :  'Bearer ' + localStorage.getItem('_token'),
          'content-disposition' : "attachment; filename=\'lutfor.png\'"
        }
      }).then(res => {
        let body = JSON.parse(res.response);
        console.log(res);
        this.wordpressService.updatePost({
          categories: post.categories,
          id: post.id,
          author: post.author,
          title: post.title,
          date: post.date,
          source_name: post.source_name,
          source_url: post.source_url,
          source_author: post.source_author,
          featured_media: body.id,
          content: post.content
        }).subscribe((response:any) => {
          console.log(response.json());
          this.navCtrl.push(BlogPostPage, {
            post: response.json()
          });
    
        }, error => {
          console.log(error);
          localStorage.removeItem('_token');
          localStorage.removeItem("author_id")
          localStorage.removeItem('username');
          localStorage.removeItem('displayname');
          localStorage.removeItem('email');
          self.events.publish('user:loggedout', {});
          this.navCtrl.push(WordpressLoginPage);
        });
      }, error => {
        console.log(error);
      });
    } else {
      this.wordpressService.updatePost({
        categories: post.categories,
        id: post.id,
        author: post.author,
        title: post.title,
        date: post.date,
        source_name: post.source_name,
        source_url: post.source_url,
        source_author: post.source_author,
        content: post.content
      }).subscribe((response:any) => {
        console.log(response.json());
        this.navCtrl.push(BlogPostPage, {
          post: response.json()
        });
  
      }, error => {
        console.log(error);
        localStorage.removeItem('_token');
        localStorage.removeItem("author_id")
        localStorage.removeItem('username');
        localStorage.removeItem('displayname');
        localStorage.removeItem('email');
        self.events.publish('user:loggedout', {});
        this.navCtrl.push(WordpressLoginPage);
      });
    }

    
  }

  categoryChange(event: { component: SelectSearchableComponent, value: any }) {
      
  };

}
