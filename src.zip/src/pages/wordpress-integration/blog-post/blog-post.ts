import { Component } from '@angular/core';
import { NavParams, NavController, LoadingController, AlertController, ModalController } from 'ionic-angular';
import { BlogFeedPage } from '../blog-feed/blog-feed';
import { BlogPostModel } from '../blog-post.model';
import { WordpressLoginPage } from '../wordpress-login/wordpress-login';
import { WordpressService } from '../wordpress-integration.service';
import { Observable } from "rxjs/Observable";
import 'rxjs/add/observable/forkJoin';
import { EditBlogPage } from '../../edit-blog/edit-blog';
import { SocialSharing } from '@ionic-native/social-sharing';
import { Events } from 'ionic-angular/';
import { ConfirmationFlagModalPage } from './confirmation-flag-modal';

@Component({
  selector: 'page-blog-post',
  templateUrl: 'blog-post.html'
})
export class BlogPostPage {

  post: BlogPostModel = new BlogPostModel();
  current_comments_page = 1;
  loggedUser: boolean = false;
  content_ready:boolean = false;
  morePagesAvailable:boolean = true;
  active: boolean = false;

  constructor(
    public navParams: NavParams,
    public navCtrl: NavController,
    public loadingCtrl: LoadingController,
    public alertCtrl: AlertController,
    public wordpressService: WordpressService,
    public socialSharing: SocialSharing,
    public events: Events,
    public modalCtrl: ModalController,
    public alertController: AlertController
  ) {}

  ngOnInit() {
    this.post = this.navParams.get('post');
    this.post.flag = 0;
    let username = this.wordpressService.getUser();
    if (username) {
      this.loggedUser = true;
    } else {
      this.loggedUser = false;
    }
    
    this.events.subscribe('user:loggedout', (obj) => {
      console.log('listened:logout');
      this.loggedUser = false;
    });

    Observable.forkJoin(
      this.getAuthorData(),
      this.getCategories(),
      this.getFlagData())
      .subscribe(data => {
        this.post.author_details = data[0];
        this.post.categories_list = data[1];
        let flagObject = JSON.parse(data[2]['_body']);
        this.post.flag = flagObject['flag_num'];
        this.content_ready = true;
      });
  }

  getAuthorData(){
    return this.wordpressService.getAuthor(this.post.author);
  }

  getCategories(){
    return this.wordpressService.getPostCategories(this.post);
  }
  
  getFlagData(){
    return this.wordpressService.getFlagPost(this.post);
  }

  report(post){

    if (this.loggedUser) {
      let myModal = this.modalCtrl.create(ConfirmationFlagModalPage, {post: post});
      myModal.onDidDismiss(data => {});
      myModal.present();
    } else {
      const alert = this.alertController.create({
        title: 'Not Logged in',
        message: 'Please login to flag this content',
        buttons: ['OK']
      });
     alert.present();
    }
  }

  goToCategoryPosts(categoryId, categoryTitle){
    this.navCtrl.push(BlogFeedPage, {
      id: categoryId,
      title: categoryTitle
    })
  }

  logOut(){
    this.wordpressService.logOut();
    this.events.publish('user:loggedout', {});
    this.navCtrl.push(WordpressLoginPage);
  }

  editPost(post){
    console.log('edit', this.wordpressService.getUser());
    if (this.wordpressService.getUser()) {
      this.navCtrl.push(EditBlogPage, {
        post: post
      });
    } else {
      this.navCtrl.push(WordpressLoginPage);
    } 
  }

  sharePost(post) {
    // message, subject, file, url
    this.socialSharing.share(post.title.rendered, post.title.rendered, "", post.link)
    .then(() => {
      console.log('Success!');
    })
    .catch(() => {
       console.log('Error');
    });
   }
}
