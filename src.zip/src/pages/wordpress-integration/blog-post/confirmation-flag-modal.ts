import { Component } from '@angular/core';
import { ViewController, NavParams } from 'ionic-angular';
import { WordpressService } from '../wordpress-integration.service';

@Component({
  selector: 'confirmation-flag-modal',
  templateUrl: 'confirmation-flag-modal.html'
})
export class ConfirmationFlagModalPage {
    post: any;
    active: boolean;
    constructor(public navParams: NavParams, 
        public viewCtrl: ViewController,
        public wordpressService: WordpressService) {
        this.post = this.navParams.get('post');
        this.active = false;
        console.log(this.post);
    }

    closeModal() {
        this.viewCtrl.dismiss({submit: false});
    }
    yesModal() {
        this.wordpressService.flagPost(this.post.id).subscribe(data => {
            this.active = true;
          }, err => {
            this.viewCtrl.dismiss({submit: true});
            console.log(err);
          });
    }

    yesCloseModal () {
        this.viewCtrl.dismiss({submit: true});
    }
}