import { MenuController } from 'ionic-angular/';
import { Component } from '@angular/core';
import { BlogFeedPage } from '../blog-feed/blog-feed';
import { NavController, LoadingController } from 'ionic-angular';
import { Validators, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { WordpressService } from '../wordpress-integration.service';
import { RegistrationPage } from '../../registration/registration';
import { AuthProvider } from '../../../providers/auth/auth';
// import { List1Page } from '../../list-1/list-1';
import { Events } from 'ionic-angular/';
import { TabsNavigationPage } from '../../../pages/tabs-navigation/tabs-navigation';
@Component({
  selector: 'page-wordpress-login',
  templateUrl: 'wordpress-login.html'
})
export class WordpressLoginPage {
  login_form: FormGroup;
  error_message: string;

  constructor(
    public navCtrl: NavController,
    public menu: MenuController,
    public loadingCtrl: LoadingController,
    public formBuilder: FormBuilder,
    public wordpressService: WordpressService,
    public authProvider: AuthProvider,
    public events: Events
  ) {}

  ionViewWillLoad() {
    this.login_form = this.formBuilder.group({
      username: new FormControl('', Validators.compose([
        Validators.required
      ])),
      password: new FormControl('', Validators.required)
    });
  }

  login(value){
    let loading = this.loadingCtrl.create();
    loading.present();
    let self = this;
    this.authProvider.postLogin(value.username, value.password).subscribe((data : any) => {
      this.authProvider.getCurrentUser(data.token).subscribe((val: any) => {
        console.log(val.id);
        localStorage.setItem("author_id", val.id);
        localStorage.setItem("_token", data.token);
        localStorage.setItem("username", data.user_nicename);
        localStorage.setItem("displayname", data.user_display_name);
        localStorage.setItem("email", data.user_email);
        self.menu.close();
        // self.navCtrl.setRoot(List1Page);
        self.navCtrl.setRoot(TabsNavigationPage);
        self.events.publish('user:loggedin', {});
        loading.dismiss();
      }, (error:any) => {
        console.log(error);
        loading.dismiss();
        this.error_message = 'Login Failed.';
      });
      
    }, (error:any) => {
      console.log(error);
      this.error_message = 'Login Failed.';
      loading.dismiss();
    });

    


  }

  skipLogin(){
    this.navCtrl.push(BlogFeedPage);
  }

  register(){
    this.navCtrl.push(RegistrationPage);
  }

}
