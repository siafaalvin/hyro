import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { environment } from '../../environment/environment';
import { Observable } from 'rxjs/Observable';
import { NativeStorage } from '@ionic-native/native-storage';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/forkJoin';

@Injectable()
export class WordpressService {
  
  headers:any;
  constructor(
    public http: Http,
    public nativeStorage: NativeStorage
  ){
    this.headers = new Headers({
      'Content-Type': 'application/json'
    });
    // 'Authorization' : 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczpcL1wvaHlyb2dsZi5uZXQiLCJpYXQiOjE1NDgyMjYzNDMsIm5iZiI6MTU0ODIyNjM0MywiZXhwIjoxNTQ4ODMxMTQzLCJkYXRhIjp7InVzZXIiOnsiaWQiOiI2NjgifX19.AJOQf-hJTCYFmaN6hdll996BxzNJ0Cxyeuw1sCRWJkM'
  }

  getRecentPosts(categoryId:number, page:number = 1){
    //if we want to query posts by category
    let category_url = categoryId ? ("&categories=" + categoryId): "";
    let headers = new Headers({
      'Content-Type': 'application/json'
    });
    return this.http.get(
      environment.wordpress_rest_api_url
      + 'posts?_embed&orderby=modified&page=' + page
      + category_url, {headers: headers})
    .map(res => res);
  }

  updatePost(post: any): any {
    let headers = new Headers({
      'Content-Type': 'application/json',
      'Authorization' : 'Bearer ' + localStorage.getItem("_token")
    });
    return this.http.post(
      environment.wordpress_rest_api_url
      + 'posts/' + post.id, post, {headers: headers});
  }

  getCustomPages(){
    return this.http.get(
      environment.wordpress_rest_api_url + 'pages', {headers: this.headers})
    .map(res => res.json());
  }

  getCustomPage(pageId){
    return this.http.get(
      environment.wordpress_rest_api_url + 'pages/' + pageId, {headers: this.headers})
    .map(res => res.json());
  }

  getCategories(){
    let headers = new Headers({
      'Content-Type': 'application/json'
    });
    return this.http.get(
      environment.wordpress_rest_api_url + 'categories', {headers: headers})
    .map(res => res.json());
  }

  getComments(postId:number, page:number = 1){
    return this.http.get(
      environment.wordpress_rest_api_url
      + "comments?post=" + postId
      + '&page=' + page, {headers: this.headers})
    .map(res => res);
  }

  getAuthor(author){
    return this.http.get(environment.wordpress_rest_api_url + "users/" + author, {headers: this.headers})
    .map(res => res.json());
  }

  getPostCategories(post){
    let observableBatch = [];

    post.categories.forEach(category => {
      observableBatch.push(this.getCategory(category));
    });

    return Observable.forkJoin(observableBatch);
  }

  getCategory(category){
    let headers = new Headers({
      'Content-Type': 'application/json'
    });
    return this.http.get(environment.wordpress_rest_api_url + "categories/" + category, {headers: headers})
    .map(res => res.json());
  }

  createComment(postId, user, comment){

    var username = 'guestaccount1';
    var password = '8eCo6%cOn6y0jPgwVolSMdHc';
    this.doPostLogin(username, password).subscribe((data: any) => {
      console.log(JSON.parse(data._body).token, "wpis");
    let header: Headers = new Headers();
    header.append('Authorization', 'Bearer ' + JSON.parse(data._body).token);

    this.http.post(environment.wordpress_rest_api_url + "comments?token=" + JSON.parse(data._body).token, {
      author_name: user.displayname,
      author_email: user.email,
      post: postId,
      content: comment
    },{ headers: JSON.parse(data._body).headers })
    .subscribe(res => {
      res.json();
      console.log(res, "response");
    }, error => {
      console.log(error);
    });
    });
  }

  getUser() {
    let token = localStorage.getItem("_token");
    let username = localStorage.getItem("username");
    if (token && username && token.length > 0) {
      return username;
    } else {
      return null;
    }
  }

  setUser(user){
    // return this.nativeStorage.setItem('ion2fullapp_wordpress_user', user);
  }

  logOut(){
    localStorage.removeItem('_token');
    localStorage.removeItem("author_id")
    localStorage.removeItem('username');
    localStorage.removeItem('displayname');
    localStorage.removeItem('email');
  }

  doLogin(username, password){
    let header : Headers = new Headers();
    header.append('Content-Type','application/x-www-form-urlencoded; charset=UTF-8');
    return this.http.post(environment.wordpress_url + '/wp-json/jwt-auth/v1/token?username='+ username + '&password=' + password, {}, { headers: header })
  }


  getPostByAuthor(page: number){
    let token = localStorage.getItem('_token');
    let author_id = localStorage.getItem('author_id');
    
    if (!token || token.length < 1) {
      return null;
    }
    let headers = new Headers({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + localStorage.getItem('_token')
    });
    return this.http.get(environment.wordpress_rest_api_url + 'posts?_embed=1&context=view&per_page=100&orderby=modified&author=' + author_id + '&page=' + page, { headers: headers }).map(res => res);
  }
  
  getFavourites(){
    let token = localStorage.getItem('_token');
    let author_id = localStorage.getItem('author_id');
    
    if (!token || token.length < 1) {
      return null;
    }
    let headers = new Headers({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + localStorage.getItem('_token')
    });
    return this.http.post(environment.wordpress_rest_api_url + 'users/favourites',{user_id: author_id}, { headers: headers }).map(res => res);
  }

  addFavourites(postId){
    let token = localStorage.getItem('_token');
    let author_id = localStorage.getItem('author_id');
    
    if (!token || token.length < 1) {
      return null;
    }
    let headers = new Headers({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + localStorage.getItem('_token')
    });
    return this.http.post(environment.wordpress_rest_api_url + 'users/favourites/add',{user_id: author_id, post: postId}, { headers: headers }).map(res => res);
  }

  removeFavourites(postId){
    let token = localStorage.getItem('_token');
    let author_id = localStorage.getItem('author_id');
    
    if (!token || token.length < 1) {
      return null;
    }
    let headers = new Headers({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + localStorage.getItem('_token')
    });
    return this.http.post(environment.wordpress_rest_api_url + 'users/favourites/remove',{user_id: author_id, post: postId}, { headers: headers }).map(res => res);
  }
  
  likes(){
    let token = localStorage.getItem('_token');
    let author_id = localStorage.getItem('author_id');
    
    if (!token || token.length < 1) {
      return null;
    }
    let headers = new Headers({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + localStorage.getItem('_token')
    });
    return this.http.post(environment.wordpress_rest_api_url + 'users/likes',{user_id: author_id}, { headers: headers }).map(res => res);
  }

  getProfile(){
    let token = localStorage.getItem('_token');
    let author_id = localStorage.getItem('author_id');
    
    if (!token || token.length < 1) {
      return null;
    }
    let headers = new Headers({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + localStorage.getItem('_token')
    });
    return this.http.get(environment.wordpress_rest_api_url + 'users/' + author_id + '?context=edit', { headers: headers }).map(res => res);
  }

  getProfileExtended(){
    let token = localStorage.getItem('_token');
    let author_id = localStorage.getItem('author_id');
    
    if (!token || token.length < 1) {
      return null;
    }
    let headers = new Headers({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + localStorage.getItem('_token')
    });

    return this.http.post(environment.wordpress_rest_api_url + 'users/profile/custom',{
      user_id: author_id
    }, { headers: headers }).map(res => res);
  }

  flagPost(post_id){
    let headers = new Headers({
      'Content-Type': 'application/json'
    });
    return this.http.post(environment.wordpress_rest_api_url + 'users/flags', {
      'post_id': post_id
    }, { headers: headers });
  }

  getFlagPost(post){
    let headers = new Headers({
      'Content-Type': 'application/json'
    }); 
    return this.http.post(environment.wordpress_rest_api_url + 'users/flags/one', {
      'post_id': post.id
    }, { headers: headers });
  }

  validateAuthToken(token){
    let header : Headers = new Headers();
    header.append('Authorization','Basic ' + token);
    return this.http.post(environment.wordpress_url + 'wp-json/jwt-auth/v1/token/validate?token=' + token,
      {}, {headers: header})
  }

  doPostLogin(username, password){
    let data = {
      username: username,
      password: password
    };

    console.log(data);
    let headers = new Headers();
    headers.set('Content-Type', 'application/json');
    return this.http.post(environment.jwt_url, data, { headers: headers});
  }
}
