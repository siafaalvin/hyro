import { UserModel } from './../profile/profile.model';
import { AuthProvider } from './../../providers/auth/auth';
import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { MenuController } from 'ionic-angular/';
// import { List1Page } from '../list-1/list-1';
import { Events } from 'ionic-angular/';
import { TabsNavigationPage } from '../../pages/tabs-navigation/tabs-navigation';
/**
 * Generated class for the RegistrationPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-registration',
  templateUrl: 'registration.html',
})
export class RegistrationPage {

  registration_form: FormGroup;
  error_message: string;

  user:UserModel = new UserModel();
  success: string;
  constructor(public navCtrl: NavController, 
    public formBuilder: FormBuilder, 
    public navParams: NavParams, 
    public events: Events,
    public menu: MenuController,
    public authProvider: AuthProvider) {
  }

  ionViewDidLoad() {
    this.registration_form = this.formBuilder.group({
      username: new FormControl('', Validators.compose([
        Validators.required
      ])),
      email: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required)
    });
  }

  register(user:any){
    let self = this;
    this.authProvider.register(user).subscribe(data => {
      this.success = "Registered successfully!";
      //start
      self.authProvider.postLogin(user.username, user.password).subscribe((data : any) => {
      self.authProvider.getCurrentUser(data.token).subscribe((val: any) => {
        this.error_message = "";
        console.log(val.id);
        localStorage.setItem("author_id", val.id);
        localStorage.setItem("_token", data.token);
        localStorage.setItem("username", data.user_nicename);
        localStorage.setItem("displayname", data.user_display_name);
        localStorage.setItem("email", data.user_email);
        self.events.publish('user:loggedin', {});
        self.menu.close();
        // self.navCtrl.setRoot(List1Page);
        self.navCtrl.setRoot(TabsNavigationPage);
      }, (error:any) => {
        console.log(error);
      });
    });
      //end
    }, error => {
      console.log(error);
      this.error_message = "Could not register!";
    });
  }

}