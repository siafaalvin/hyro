import { Component } from '@angular/core';
import { NavController, LoadingController } from 'ionic-angular';
import { Keyboard } from '@ionic-native/keyboard';
import 'rxjs/Rx';

import { List1Model } from './list-1.model';
import { List1Service } from './list-1.service';
import { SocialSharing } from '@ionic-native/social-sharing';
import { BlogFeedModel } from '../wordpress-integration/blog-post.model';
import { WordpressService } from '../wordpress-integration/wordpress-integration.service';
import { BlogPostPage } from '../wordpress-integration/blog-post/blog-post';


@Component({
  selector: 'list-1-page',
  templateUrl: 'list-1.html'
})
export class List1Page {
  list1: List1Model = new List1Model();
  loading: any;
  sort: number;
  items:any;
  searchQuery:any;
  loggedUser: boolean = false;
  categoryId: number;
  categoryTitle: string;
  current_posts_page = 1;
  favouriteList: any[];
  morePagesAvailable:boolean = true;
  feed: BlogFeedModel = new BlogFeedModel();

  constructor(
    public nav: NavController,
    public list1Service: List1Service,
    public loadingCtrl: LoadingController,
    public socialSharing: SocialSharing,
    public wordpressService: WordpressService,
    public keyboard: Keyboard
  ) {
    this.loading = this.loadingCtrl.create();
    this.sort = 0;
    this.favouriteList = [];
    
    
  }

  ionViewDidLoad() {
    let token = localStorage.getItem('_token');
    if (token && token.length > 1) {
      this.wordpressService.getFavourites().subscribe((data: any) => {
        let body = JSON.parse(data._body);
        this.favouriteList = body.list.map((element) => { return Number(element);});
      });
    }
    this.loadContents(this.sort);
  }

  isFavourited(postId) {
    if (this.favouriteList.indexOf(postId) > -1) {
      return true;
    }
    return false;
  }

  loadContents(sort:number): any {
    // this.loading.present();
    this.list1Service
      .getData(sort)
      .subscribe((data:any) => {
        this.items = data.json();
        this.feed.posts_count = Number(data.headers.get('x-wp-total'));
        this.feed.posts_pages = Number(data.headers.get('x-wp-totalpages'));

        for(let post of data.json()){
          post.excerpt.rendered = post.excerpt.rendered.split('<a')[0] + "</p>";
          this.items.push(post);
        }
        // this.loading.dismiss();
      });
  }

  onCancel(event){
    this.searchQuery = "";
    window['Keyboard'].hide();

  }

  addFavourite(item_id) {
    let token = localStorage.getItem('_token');
    if (token && token.length > 1) {
      this.wordpressService.addFavourites(item_id).subscribe((data: any) => {
        this.favouriteList.push(Number(item_id));
      });
    }
  }


  removeFavourite(item_id) {
    let itemId = Number(item_id);
    let token = localStorage.getItem('_token');
    if (token && token.length > 1) {
      this.wordpressService.removeFavourites(item_id).subscribe((data: any) => {
        this.favouriteList = this.favouriteList.filter((element) => {return Number(element) != itemId});
      });
    }
  }

  getPosts(event: any){
    const val = event.target.value;

    if (val && val.trim() != '') {
      window['Keyboard'].hide();
      return this.items = this.items.filter((post:any) => {
        return (post.title.rendered.toLowerCase().indexOf(val.toLowerCase()) > -1);
      });
    }

    this.loadContents(this.sort);
  }

  readMore(post) {
		this.nav.push(BlogPostPage, {
		  post: post
		});
  }
  
  sortPost(){
    this.loadContents(this.sort);
  }

  sharePost(post) {
    console.log(post);
    //this code is to use the social sharing plugin
    // message, subject, file, url
    this.socialSharing.share(post.title.rendered, post.title.rendered, "", post.link)
    .then(() => {
      console.log('Success!');
    })
    .catch(() => {
       console.log('Error');
    });
   }

   loadMorePosts(infiniteScroll) {
    this.morePagesAvailable = this.feed.posts_pages > this.current_posts_page;
    if(this.morePagesAvailable)
    {
      this.current_posts_page +=1;

      this.list1Service
      .getData(this.sort, this.current_posts_page)
      .subscribe((data:any) => {
        for(let post of data.json()){
          post.excerpt.rendered = post.excerpt.rendered.split('<a')[0] + "</p>";
          this.items.push(post);
        }
      }, err => {
        console.log(err);
      })
    }
  }

   


}
